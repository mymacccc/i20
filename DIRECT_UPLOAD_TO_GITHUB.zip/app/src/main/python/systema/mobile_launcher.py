import os, sys, threading
from pathlib import Path

def start_server(storage_path: str, port: int = 8766):
    here = Path(__file__).resolve().parent
    if str(here) not in sys.path:
        sys.path.insert(0, str(here))
    data_dir = Path(storage_path) / "SystemA_Data"
    data_dir.mkdir(parents=True, exist_ok=True)
    os.environ["SYSTEM_A_DATA"] = str(data_dir)
    os.environ["HOST"] = "127.0.0.1"
    os.environ["PORT"] = str(port)

    from systema.app import app
    from waitress import serve

    threading.Thread(
        target=lambda: serve(app, host="127.0.0.1", port=port, threads=4),
        daemon=True
    ).start()
    return f"http://127.0.0.1:{port}"

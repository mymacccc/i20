from pathlib import Path
from contextlib import contextmanager
import hashlib, json, re, sqlite3, uuid, io, math, random, os, shutil, subprocess, tempfile
from datetime import datetime, timezone
from zoneinfo import ZoneInfo
import fitz
from flask import Flask, request, jsonify, send_file

ROOT = Path(__file__).resolve().parent
DATA = Path(os.environ.get('SYSTEM_A_DATA',str(ROOT/'data')))
DATA.mkdir(parents=True,exist_ok=True)
UPLOADS = DATA / 'uploads'
UPLOADS.mkdir(exist_ok=True)
app = Flask(__name__, static_folder='static')
app.config['MAX_CONTENT_LENGTH'] = 50 * 1024 * 1024
MASTERS = {'ai': ('ai_master.pdf', 2), 'similarity': ('similarity_master.pdf', 3)}
FONT_PATHS={key:ROOT/'fonts'/(key+'.ttf') for key in ['NotoR','NotoSB','LexM','LexSB']}
DEFAULT_SOURCE_POOL=json.loads((ROOT/'data/source_pool.json').read_text())
DEFAULT_SOURCE_CATALOG=json.loads((ROOT/'data/source_catalog.json').read_text())
FONTS={key:fitz.Font(fontfile=str(path)) for key,path in FONT_PATHS.items()}

@contextmanager
def db():
    c = sqlite3.connect(DATA / 'system_a.db')
    c.row_factory = sqlite3.Row
    try:
        with c:
            yield c
    finally:
        c.close()

def init():
    with db() as c:
        c.executescript('''CREATE TABLE IF NOT EXISTS projects(id TEXT PRIMARY KEY, name TEXT, state TEXT, updated TEXT);
        CREATE TABLE IF NOT EXISTS exports(id INTEGER PRIMARY KEY, project_id TEXT, created TEXT, pages INTEGER);
        CREATE TABLE IF NOT EXISTS templates(kind TEXT PRIMARY KEY, filename TEXT, sha256 TEXT);''')
        for kind, (filename, _) in MASTERS.items():
            digest = hashlib.sha256((ROOT/'templates'/filename).read_bytes()).hexdigest()
            saved = c.execute('SELECT sha256 FROM templates WHERE kind=?', (kind,)).fetchone()
            if saved and saved['sha256'] != digest:
                raise RuntimeError('Master template checksum mismatch: '+filename)
            c.execute('INSERT OR IGNORE INTO templates VALUES(?,?,?)', (kind,filename,digest))
init()

def get_project(pid):
    with db() as c:
        r = c.execute('SELECT * FROM projects WHERE id=?',(pid,)).fetchone()
    if not r: raise ValueError('Project not found')
    s = json.loads(r['state'])
    s['id'] = pid
    apply_ai_threshold(s)
    s.setdefault('source_pool',DEFAULT_SOURCE_POOL)
    s['overview_pages']=report_prefix(s)
    return s

def save(s):
    with db() as c:
        c.execute('INSERT OR REPLACE INTO projects VALUES(?,?,?,?)', (s['id'], s['name'], json.dumps(s), datetime.now(timezone.utc).isoformat()))

def text(page, box, value, size=11, bold=False, role=None, color=(.14,.14,.14), background=(1,1,1)):
    rect=fitz.Rect(box)
    page.draw_rect(rect, color=None, fill=background, overlay=True)
    value=str(value)
    key=role or ('LexM' if size>=16 else 'NotoSB' if bold else 'NotoR')
    font=FONTS[key]
    pdfkey='SA_'+key
    page.insert_font(fontname=pdfkey,fontfile=str(FONT_PATHS[key]))
    if not value: return
    if '\n' not in value:
        width=font.text_length(value,fontsize=size)
        fs=min(size,(rect.height-1)/(font.ascender-font.descender),size*(rect.width-2)/max(width,1))
        if fs<6: raise ValueError('Text is too long for a template field')
        page.insert_text((rect.x0,rect.y0+font.ascender*fs),value,fontsize=fs,fontname=pdfkey,color=color,overlay=True)
        return
    for step in range(0,max(1,int((size-6)*4)+1)):
        fs=size-step*.25
        result=page.insert_textbox(rect,value,fontsize=fs,fontname=pdfkey,color=color,overlay=True)
        if result>=0:return
    raise ValueError('Text is too long for a template field')

def cover_fields(page,s):
    # Native reference families and coordinates; masters stay immutable.
    text(page,(48,444,762,480),s.get('author',''),26.25,True,role='LexSB')
    text(page,(48,490,762,525),s['filename'],22.5,role='LexM')
    text(page,(45,525,71,551),'',9)
    page.insert_image(fitz.Rect(48,528,64,544),filename=str(ROOT/'assets'/'academic_icon.png'))
    text(page,(74.25,528,762,548),s['institution'],10.5)
    text(page,(48,587,762,608),'Document Details',13.5,True)
    labels=[('Submission ID',625.5,643.9,s['submission_id']),('Submission Date',673.5,691.9,s['submission_date']),('Download Date',721.5,739.9,s['download_date']),('File Name',769.5,787.9,s['filename']),('File Size',817.5,835.9,f"{s['bytes']/1024:.1f} KB")]
    for label,y,vy,value in labels:
        text(page,(48,y,328,y+15),label,9.375,True,color=(.50,.50,.50))
        text(page,(48,vy,510,vy+16),value,9.375,True)
    # Keep the original pale panel, with native semibold metrics.
    text(page,(544,637,650,728),'',9)
    page.draw_rect(fitz.Rect(533,622,651,727),color=None,fill=(.973,.973,.973),overlay=True)
    for y,value in [(641.3,f"{s['pages']} Pages"),(670.4,f"{s['words']:,} Words"),(699.5,f"{s['characters']:,} Characters")]:
        text(page,(549,y,646,y+16),value,9.375,True,background=(.973,.973,.973))

AI_DESCRIPTION='The percentage indicates the combined amount of likely AI-generated text as\nwell as likely AI-generated text that was also likely revised by AI.'
AI_DISCLAIMER='Our AI writing assessment is designed to help educators identify text that might be prepared by a generative AI tool. Our AI writing assessment may not always be accurate (it may misidentify\nwriting that is likely human generated as AI generated and likely AI generated as human generated) so it should not be used as the sole basis for adverse actions against a student. It takes\nfurther scrutiny and human judgment in conjunction with an organization\'s application of its specific academic policies to determine whether any academic misconduct has occurred.'

AI_STAR_DESCRIPTION='AI detection includes the possibility of false positives. Although some text in\nthis submission is likely AI generated, scores below the 20% threshold are not\nsurfaced because they have a higher likelihood of false positives.'

def ai_overview(page,s,master):
    star=s['result']=='*'
    # Keep the master's rounded blue caution background in both modes.
    text(page,(48,107.2,400,136),('*%' if star else s['result'])+' detected as AI',22.5,role='LexM')
    text(page,(48,133.1,400,181 if star else 168),AI_STAR_DESCRIPTION if star else AI_DESCRIPTION,9.375)
    blue=(.816,.910,.976)
    text(page,(420.75,112.8,756,127),'Caution: Review required.',7.875,True,background=blue)
    warning=['It is essential to understand the limitations of AI detection before making decisions','about a student’s work. We encourage you to learn more about Turnitin’s AI detection','capabilities before using the tool.']
    text(page,(420.75,131.8,756,174),'',7.875,background=blue)
    for i,line in enumerate(warning):
        text(page,(420.75,134.45+i*10.59,756,147+i*10.59),line,7.875,background=blue)
    text(page,(45,206,766,406),'',9)
    if not star:
        icon=fitz.Rect(47,218,66,240)
        page.show_pdf_page(icon,master,1,clip=icon)
        count=str(s.get('ai_segments',0))
        width=FONTS['NotoSB'].text_length(count,fontsize=9.375)
        text(page,(69,220.4,69+width+2,234.5),count,9.375,True)
        text(page,(69+width+2,220.4,700,235.5),' AI-generated '+s['result'],9.375)
        text(page,(69,233.65,762,250),'Likely generated or likely generated and revised by AI.',9.375,color=(.5,.5,.5))
        page.draw_line((48,265.5),(762,265.5),color=(.86,.86,.86),width=.75)
    y=219 if star else 288
    text(page,(48,y,762,y+14),'Disclaimer',7.875,True,color=(.5,.5,.5))
    text(page,(48,y+11,762,y+55),AI_DISCLAIMER,7.875,color=(.5,.5,.5))
    page.draw_line((48,y+61.5),(762,y+61.5),color=(.86,.86,.86),width=.75)

def clear_template_text(page, boxes):
    for box in boxes:
        page.add_redact_annot(fitz.Rect(box),fill=False)
    page.apply_redactions(images=0,graphics=0,text=0)

def header(page, index, total, label, sid):
    for y in (36.5,995.0):
        text(page,(141.75,y,580,y+16),f'Page {index} of {total} - {label}',7.875)
        text(page,(609.75,y,766,y+16),'Submission ID  '+sid,7.875)

def apply_ai_threshold(s):
    if s['kind']=='ai' and s['result']!='*' and float(s['result'].rstrip('%'))<20:
        s['result']='*'
        s['highlights']={}
        s.pop('auto_coverage',None)

def table_regions(page):
    regions=[]
    for strategy in ('lines','text'):
        for table in page.find_tables(strategy=strategy).tables:
            if table.row_count>=2 and table.col_count>=2:
                rect=fitz.Rect(table.bbox)
                if strategy=='text' and any(rect.intersects(ruled) for ruled in regions):continue
                regions.append(rect)
    return regions

def highlight_words(page,kind):
    regions=table_regions(page)
    words=page.get_text('words',sort=True)
    if kind=='ai':
        for block in page.get_text('dict')['blocks']:
            if block['type']==1: regions.append(fitz.Rect(block['bbox']))
        blocks={}
        for w in words: blocks.setdefault(w[5],[]).append(w[4])
        qualifying=set()
        for block,items in blocks.items():
            text=' '.join(items)
            if len(items)>=20 and sum(c.isalpha() for c in text)/max(1,len(text))>.55:
                qualifying.add(block)
        words=[w for w in words if w[5] in qualifying]
    return [w for w in words if not any(fitz.Rect(w[:4]).intersects(r) for r in regions)]

def highlighting_enabled(result):
    return result != '*' and float(result.rstrip('%')) > 0

def automatic_highlights(s):
    """Select a target word proportion for simulation; never classify text."""
    source=fitz.open(UPLOADS/s['source'])
    pages=[highlight_words(p,s['kind']) for p in source]
    total=sum(map(len,pages))
    target=round(total*float(s['result'].rstrip('%'))/100) if highlighting_enabled(s['result']) else 0
    highlights={};cumulative=0;allocated=0
    placement=fitz.Rect(s['placement'])
    for index,words in enumerate(pages):
        cumulative+=len(words)
        upto=round(cumulative*target/total) if total else 0
        wanted=upto-allocated;allocated=upto
        bounds=source[index].rect
        scale=min(placement.width/bounds.width,placement.height/bounds.height)
        ox=placement.x0+(placement.width-bounds.width*scale)/2
        oy=placement.y0+(placement.height-bounds.height*scale)/2
        lines=[];previous=None;previous_word=None
        selected=words[:wanted]
        if s['kind']=='similarity':
            chunks=[list(range(k,min(k+6,len(words)))) for k in range(0,len(words),6)]
            random.Random(s['id']+':phrases:'+str(index)).shuffle(chunks)
            indices=[k for chunk in chunks for k in chunk][:wanted]
            selected=[words[k] for k in sorted(indices)]
        for word in selected:
            key=word[5:7]
            rect=fitz.Rect(word[:4])
            if lines and key==previous and (s['kind']!='similarity' or word[7]==previous_word+1): lines[-1] |= rect
            else: lines.append(rect)
            previous=key;previous_word=word[7]
        if lines:
            highlights[str(index)]=[[max(0,(ox+(r.x0-bounds.x0)*scale)/810),max(0,(oy+(r.y0-bounds.y0)*scale)/1049.0399169921875),min(1,(ox+(r.x1-bounds.x0)*scale)/810),min(1,(oy+(r.y1-bounds.y0)*scale)/1049.0399169921875)] for r in lines]
    source.close()
    return highlights,dict(selected_words=target,total_words=total,percentage=100*target/total if total else 0)

PALETTE=[(.76,.04,.43),(.15,.36,.72),(.02,.48,.33),(.46,.16,.86)]

def simulated_sources(s):
    score=float(s['result'].rstrip('%')) if highlighting_enabled(s['result']) else 0
    if not score: return []
    pool=s.get('source_pool',DEFAULT_SOURCE_POOL)
    count=min(len(pool),max(1,math.ceil(score*.8)+1))
    points=round(score*100)
    count=min(count,points)
    rng=random.Random(s['id']+':'+str(score))
    if pool==DEFAULT_SOURCE_POOL:
        publications=[r for r in DEFAULT_SOURCE_CATALOG if r['category']=='Publication']
        internet=[r for r in DEFAULT_SOURCE_CATALOG if r['category']=='Internet']
        pubcount=min(len(publications),max(1,round(count*.7)))
        selected=rng.sample(publications,pubcount)+rng.sample(internet,count-pubcount)
        rng.shuffle(selected)
    else: selected=[dict(category='Internet',title=x) for x in rng.sample(pool,count)]
    weights=sorted([math.exp(-i/5)*rng.uniform(.7,1.3) for i in range(count)],reverse=True)
    total=sum(weights)
    # Positive, varied contributions add up exactly to the entered percentage.
    remaining=points-count
    fractions=[remaining*w/total for w in weights]
    contributions=[1+int(x) for x in fractions]
    leftover=points-sum(contributions)
    for i in sorted(range(count),key=lambda i:fractions[i]-int(fractions[i]),reverse=True)[:leftover]: contributions[i]+=1
    contributions.sort(reverse=True)
    return [dict(number=i+1,category=selected[i]['category'],title=selected[i]['title'],reference='',percentage=value/100,color=list(PALETTE[i%len(PALETTE)])) for i,value in enumerate(contributions)]

def source_rows(s):
    return s.get('source_preview',[]) if s.get('source_mode','auto')=='auto' else []

def report_prefix(s):
    if s['kind']=='ai': return 2
    return 3+math.ceil(max(0,len(source_rows(s))-10)/15)

def similarity_summary(page,s,compact=False):
    rows=source_rows(s)
    # Retain the master's icons and rounded panel while moving them to reference positions.
    original=fitz.open(ROOT/'templates'/MASTERS['similarity'][0])
    mp=original[1]
    group_icons=[mp.get_pixmap(matrix=fitz.Matrix(3,3),clip=fitz.Rect(47,298+i*33,67,324+i*33)).tobytes('png') for i in range(4)]
    category_icons=[mp.get_pixmap(matrix=fitz.Matrix(3,3),clip=fitz.Rect(425,299+i*18.5,441,316+i*18.5)).tobytes('png') for i in range(3)]
    clear_template_text(mp,[fitz.Rect(400,475,765,557)])
    blue=mp.get_pixmap(matrix=fitz.Matrix(2,2),clip=fitz.Rect(399,475,756,563)).tobytes('png')
    clear_template_text(page,[fitz.Rect(45,65,766,570)])
    text(page,(45,65,766,570),'',9)
    text(page,(48,74,760,101),s['result']+' Overall Similarity',22.5,role='LexM')
    text(page,(48,108,762,122),'The combined total of all matches, including overlapping sources, for each database.',9.375,color=(.5,.5,.5))
    text(page,(48,137,762,155),'Filtered from the Report',13.5,True)
    enabled=[k for k in ['Bibliography','Quoted Text','Cited Text','Small Matches'] if s['filters'].get(k)]
    for i,label in enumerate(enabled):
        text(page,(51,165+i*18,61,180+i*18),'›',9.375)
        text(page,(64,165+i*18,384,181+i*18),label,9.375)
    if not enabled: text(page,(64,165,384,181),'No filters selected',9.375,color=(.5,.5,.5))
    page.draw_line((48,247),(762,247),color=(.86,.86,.86),width=.75)
    text(page,(48,269,384,288),'Match Groups',13.5,True)
    text(page,(395,269,762,288),'Top Sources',13.5,True)
    groups=[[r for j,r in enumerate(rows) if j%4==i] for i in range(4)]
    labels=['Not Cited or Quoted','Missing Quotations','Missing Citation','Cited and Quoted']
    descriptions=['Matches with neither in-text citation nor quotation marks','Matches that are still very similar to source material','Matches that have quotation marks, but no in-text citation','Matches with in-text citation present, but no quotation marks']
    for i,label in enumerate(labels):
        y=300+i*33
        page.insert_image(fitz.Rect(47,y-2,67,y+24),stream=group_icons[i])
        value=sum(round(r['percentage']*100) for r in groups[i])/100
        text(page,(70,y,384,y+16),f'{len(groups[i])} {label}  {value:g}%',9.375)
        text(page,(70,y+14,384,y+30),descriptions[i],9.375,color=(.5,.5,.5))
    for i,(category,label) in enumerate([('Internet','Internet sources'),('Publication','Publications'),('Submitted works','Submitted works (Student Papers)')]):
        y=300+i*18.5
        value=sum(round(r['percentage']*100) for r in rows if r['category']==category)/100
        text(page,(395,y,430,y+15),f'{value:g}%',9.375)
        page.insert_image(fitz.Rect(437,y,450,y+15),stream=category_icons[i])
        text(page,(453,y,762,y+15),label,9.375)
    page.draw_line((48,442),(762,442),color=(.86,.86,.86),width=.75)
    original.close()

def rounded_pill(page,box,color):
    r=fitz.Rect(box);radius=r.height/2
    page.draw_rect(fitz.Rect(r.x0+radius,r.y0,r.x1-radius,r.y1),color=None,fill=color)
    page.draw_oval(fitz.Rect(r.x0,r.y0,r.x0+2*radius,r.y1),color=None,fill=color)
    page.draw_oval(fitz.Rect(r.x1-2*radius,r.y0,r.x1,r.y1),color=None,fill=color)

def similarity_sources_page(page,s,extra_index=0):
    text(page,(45,65,765,977),'',10)
    rows=source_rows(s)
    if extra_index==0:
        # Repeat the reference's compact match-group/category panel above the source list.
        paneldoc=fitz.open();panel=paneldoc.new_page(width=810,height=1049.0399169921875)
        similarity_summary(panel,s)
        panelpng=panel.get_pixmap(matrix=fitz.Matrix(3,3),clip=fitz.Rect(45,263,765,441)).tobytes('png')
        page.insert_image(fitz.Rect(45,73,765,251),stream=panelpng)
        paneldoc.close()
        page.draw_line((48,264),(762,264),color=(.86,.86,.86),width=.75)
        text(page,(48,283,762,304),'Top Sources',13.5,True)
        text(page,(48,309,762,325),'The sources with the highest number of matches within the submission. Overlapping sources will not be displayed.',7.875,color=(.5,.5,.5))
        text(page,(48,327,762,342),'Preview sources',7.875,color=(.5,.5,.5))
        selected=rows[:10];y=354;step=58
    else:
        begin=10+(extra_index-1)*15;selected=rows[begin:begin+15];y=78;step=58
        text(page,(48,65,762,77),'Preview sources',7.875,color=(.5,.5,.5))
    if s.get('source_mode','auto')=='manual':
        text(page,(48,y,762,960),'\n\n'.join(s.get('sources',[])) or 'No manual source rows entered.',12)
        return
    if not rows:
        text(page,(48,y,762,y+24),'No source rows in * or 0% mode.',12)
        return
    for row in selected:
        color=tuple(row['color']);tint=tuple(1-(1-x)*.14 for x in color)
        rounded_pill(page,(48,y,78,y+18),color)
        rounded_pill(page,(85,y,177,y+18),tint)
        page.insert_font(fontname='SA_NotoSB',fontfile=str(FONT_PATHS['NotoSB']))
        number=str(row['number']);width=FONTS['NotoSB'].text_length(number,fontsize=8)
        page.insert_text((63-width/2,y+12),number,fontsize=8,fontname='SA_NotoSB',color=(1,1,1))
        label=row['category'];width=FONTS['NotoSB'].text_length(label,fontsize=8)
        page.insert_text((131-width/2,y+12),label,fontsize=8,fontname='SA_NotoSB',color=(.15,.15,.15))
        title=row['title']
        while FONTS['NotoSB'].text_length(title,fontsize=9.375)>460:
            title=title[:-5].rstrip()+' …'
        text(page,(48,y+22,511,y+39),title,9.375,True)
        value='<1%' if row['percentage']<1 else f"{row['percentage']:g}%"
        text(page,(522,y+22,568,y+39),value,9.375,True)
        page.draw_line((48,y+46),(568,y+46),color=(.90,.91,.92),width=.4)
        y+=step

def compose(s, only=None):
    filename, master_pre = MASTERS[s['kind']]
    pre=report_prefix(s)
    with db() as c:
        expected=c.execute('SELECT sha256 FROM templates WHERE kind=?',(s['kind'],)).fetchone()['sha256']
    path=ROOT/'templates'/filename
    if hashlib.sha256(path.read_bytes()).hexdigest()!=expected: raise ValueError('Master template was changed')
    master=fitz.open(path)
    source=fitz.open(UPLOADS/s['source'])
    out=fitz.open()
    total=pre+len(source)
    indices=range(total) if only is None else [only]
    for index in indices:
        if index<0 or index>=total: raise ValueError('Page out of range')
        mi=min(index,master_pre-1) if index<pre else master_pre
        out.insert_pdf(master,from_page=mi,to_page=mi)
        page=out[-1]
        label='Cover Page' if index==0 else ('AI Writing Overview' if s['kind']=='ai' else 'Integrity Overview') if index<pre else ('AI Writing Submission' if s['kind']=='ai' else 'Integrity Submission')
        boxes=[(138,30,768,56),(138,990,768,1020)]
        if index==0: boxes.append((45,440,765,865))
        elif index<pre and s['kind']=='ai': boxes.append((45,104,768,409))
        elif index==1 and s['kind']=='similarity':
            boxes.extend([(45,73,765,103),(45,159,384,239),(68,297,765,430),(45,476,391,501)])
        elif index<pre: boxes.append((45,65,765,977))
        clear_template_text(page,boxes)
        header(page,index+1,total,label,s['submission_id'])
        if index==0:
            cover_fields(page,s)
        elif index<pre:
            if s['kind']=='ai':
                ai_overview(page,s,master)
            else:
                if index==1:
                    similarity_summary(page,s)
                else:
                    similarity_sources_page(page,s,index-2)
        else:
            j=index-pre
            placement=fitz.Rect(s['placement'])
            page.show_pdf_page(placement,source,j,keep_proportion=True)
            if highlighting_enabled(s['result']):
                badge_rows={}
                source_page=source[j]
                bounds=source_page.rect
                scale=min(placement.width/bounds.width,placement.height/bounds.height)
                ox=placement.x0+(placement.width-bounds.width*scale)/2-bounds.x0*scale
                oy=placement.y0+(placement.height-bounds.height*scale)/2-bounds.y0*scale
                blocked=[fitz.Rect(ox+r.x0*scale,oy+r.y0*scale,ox+r.x1*scale,oy+r.y1*scale)
                         for r in table_regions(source_page)]
                for hi,h in enumerate(s['highlights'].get(str(j),[])):
                    r=fitz.Rect(h[0]*page.rect.width,h[1]*page.rect.height,h[2]*page.rect.width,h[3]*page.rect.height)
                    if any(r.intersects(table) for table in blocked): continue
                    rows=source_rows(s)
                    position=sum(len(s['highlights'].get(str(k),[])) for k in range(j))+hi
                    fraction=((position+.5)*0.6180339887498949)%1
                    cumulative=0; chosen=PALETTE[hi%len(PALETTE)];source_number=None
                    for row in rows:
                        cumulative+=row['percentage']/float(s['result'].rstrip('%'))
                        if fraction<=cumulative:
                            chosen=tuple(row['color']);source_number=row['number'];break
                    if s['kind']=='ai':
                        page.draw_rect(r,color=None,fill=(.1,.8,.94),fill_opacity=.3,overlay=True)
                    else:
                        page.draw_rect(r,color=None,fill=chosen,fill_opacity=.16,overlay=True)
                        # Circular source flags occupy the left margin; same-line flags sit side by side.
                        key=round((r.y0+r.y1)/2,1)
                        seen=badge_rows.setdefault(key,[])
                        if source_number not in seen and len(seen)<2:
                            cx=34+len(seen)*23;cy=(r.y0+r.y1)/2
                            page.draw_circle(fitz.Point(cx,cy),9,color=None,fill=chosen,overlay=True)
                            page.insert_font(fontname='SA_NotoSB',fontfile=str(FONT_PATHS['NotoSB']))
                            number=str(source_number) if source_number is not None else '•'
                            width=FONTS['NotoSB'].text_length(number,fontsize=7.5)
                            page.insert_text((cx-width/2,cy+2.7),number,fontsize=7.5,fontname='SA_NotoSB',color=(1,1,1),overlay=True)
                            seen.append(source_number)
    master.close();source.close()
    return out

@app.errorhandler(ValueError)
def invalid(e): return jsonify(error=str(e)),400
@app.errorhandler(413)
def large(e): return jsonify(error='PDF is larger than the 50 MB limit'),413

@app.get('/')
def home(): return app.send_static_file('index.html')
@app.get('/api/templates')
def templates():
    with db() as c: rows=[dict(r) for r in c.execute('SELECT * FROM templates')]
    return jsonify(rows)
@app.get('/api/templates/<kind>')
def master_download(kind):
    if kind not in MASTERS: raise ValueError('Unknown template')
    return send_file(ROOT/'templates'/MASTERS[kind][0],mimetype='application/pdf')
@app.get('/api/projects')
def projects():
    with db() as c: return jsonify([dict(r) for r in c.execute('SELECT id,name,updated FROM projects ORDER BY updated DESC')])
def word_converter():
    configured=os.environ.get('SYSTEM_A_SOFFICE')
    local=ROOT/'libreoffice/program/soffice.exe'
    if not configured and local.exists(): return str(local)
    installed=Path(os.environ.get('PROGRAMFILES','C:/Program Files'))/'LibreOffice/program/soffice.exe'
    if not configured and installed.exists(): return str(installed)
    bundled=Path.home()/'.cache/codex-runtimes/codex-primary-runtime/dependencies/bin/override/soffice'
    return configured or shutil.which('soffice') or shutil.which('libreoffice') or (str(bundled) if bundled.exists() else None)

def submission_pdf(data,extension):
    if extension=='.pdf': return data
    converter=word_converter()
    if not converter: raise ValueError('Word uploads require LibreOffice. Install LibreOffice or set SYSTEM_A_SOFFICE to its executable.')
    with tempfile.TemporaryDirectory(prefix='system-a-word-') as tmp:
        folder=Path(tmp);incoming=folder/('submission'+extension);incoming.write_bytes(data)
        profile=(folder/'profile').as_uri()
        try:
            result=subprocess.run([converter,'-env:UserInstallation='+profile,'--headless','--convert-to','pdf','--outdir',tmp,str(incoming)],capture_output=True,timeout=120)
        except subprocess.TimeoutExpired: raise ValueError('Word conversion timed out. Try a smaller document or upload a PDF.')
        output=folder/'submission.pdf'
        if result.returncode or not output.exists(): raise ValueError('Unable to convert this Word document. Use an unencrypted .doc or .docx file.')
        return output.read_bytes()

@app.post('/api/projects')
def create():
    f=request.files.get('file')
    if not f: raise ValueError('Choose a PDF or Word document first')
    kind=request.form.get('kind','ai')
    if kind not in MASTERS: raise ValueError('Unknown template')
    original=f.read()
    extension=Path(f.filename or '').suffix.lower()
    if extension not in ['.pdf','.docx','.doc']: raise ValueError('Upload a PDF, DOCX or DOC file')
    data=submission_pdf(original,extension)
    try: d=fitz.open(stream=data,filetype='pdf')
    except Exception: raise ValueError('Unable to read this PDF')
    if d.is_encrypted or len(d)==0: raise ValueError('Use an unencrypted PDF with at least one page')
    body='\n'.join(p.get_text() for p in d)
    pid=uuid.uuid4().hex
    source=pid+'.pdf'
    (UPLOADS/source).write_bytes(data)
    if extension!='.pdf': (UPLOADS/(pid+extension)).write_bytes(original)
    local=datetime.now(ZoneInfo('Asia/Kolkata'))
    now=f"{local.strftime('%b')} {local.day}, {local.year}, {local.hour%12 or 12}:{local.minute:02d} {local.strftime('%p')} GMT+5:30"
    s=dict(id=pid,author='',ai_segments=0,name=request.form.get('name') or Path(f.filename).stem,kind=kind,source=source,filename=Path(f.filename).name,bytes=len(original),pages=len(d),words=len(body.split()),characters=len(body),result='*',highlight_mode='auto',source_mode='auto',source_preview=[],institution='Local research project',submission_id='',submission_date=now,download_date=now,highlights={},filters={'Bibliography':False,'Quoted Text':False,'Cited Text':False,'Small Matches':False},sources=[],placement=[76,61,715,981])
    d.close();save(s)
    return jsonify(s),201
@app.get('/api/projects/<pid>')
def load(pid): return jsonify(get_project(pid))
@app.put('/api/projects/<pid>')
def update(pid):
    s=get_project(pid); patch=request.get_json()
    if not isinstance(patch,dict): raise ValueError('Invalid project update')
    for k in ['name','author','filename','institution','submission_id','submission_date','download_date']:
        if k in patch:
            if not isinstance(patch[k],str) or (k not in ('author','submission_id') and not patch[k].strip()) or len(patch[k])>180: raise ValueError('Invalid '+k)
            s[k]=patch[k]
    if 'ai_segments' in patch:
        if type(patch['ai_segments'])!=int or not 0<=patch['ai_segments']<=999999: raise ValueError('Use a non-negative AI section count')
        s['ai_segments']=patch['ai_segments']
    if 'kind' in patch:
        if patch['kind'] not in MASTERS: raise ValueError('Unknown template')
        s['kind']=patch['kind']
    if 'source_pool' in patch:
        pool=patch['source_pool']
        if not isinstance(pool,list) or not 1<=len(pool)<=300: raise ValueError('Enter 1–300 website URLs')
        if any(not isinstance(x,str) or len(x)>500 or not re.fullmatch(r'(?:https?://)?[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}(?:/[^\s]*)?',x) for x in pool): raise ValueError('Use website URLs, one per line')
        s['source_pool']=list(dict.fromkeys(pool))
    if 'source_mode' in patch:
        if patch['source_mode'] not in ['auto','manual']: raise ValueError('Invalid source mode')
        s['source_mode']=patch['source_mode']
    if 'highlight_mode' in patch:
        if patch['highlight_mode'] not in ['auto','manual']: raise ValueError('Invalid highlight mode')
        s['highlight_mode']=patch['highlight_mode']
    if 'result' in patch:
        r=str(patch['result']).strip()
        if r!='*':
            if not re.fullmatch(r'\d+(\.\d+)?%?',r): raise ValueError('Enter * or a percentage from 0 to 100')
            v=float(r.rstrip('%'))
            if not 0<=v<=100: raise ValueError('Percentage must be between 0 and 100')
            r=f'{v:g}%'
        s['result']=r
    if 'placement' in patch:
        p=patch['placement']
        if not isinstance(p,list) or len(p)!=4 or not all(isinstance(x,(float,int)) and math.isfinite(x) for x in p) or not (75<=p[0]<p[2]<=716 and 60<=p[1]<p[3]<=982): raise ValueError('Placement must fit within the blank submission area')
        s['placement']=p
    if 'filters' in patch:
        p=patch['filters']
        if not isinstance(p,dict) or set(p)!=set(s['filters']) or not all(type(v)==bool for v in p.values()): raise ValueError('Invalid filter states')
        s['filters']=p
    if 'sources' in patch:
        p=patch['sources']
        if not isinstance(p,list) or len(p)>30 or not all(isinstance(x,str) and len(x)<=160 for x in p): raise ValueError('Use up to 30 source rows, each under 160 characters')
        s['sources']=p
    if 'highlights' in patch:
        hs=patch['highlights']
        if not isinstance(hs,dict): raise ValueError('Invalid highlights')
        for key,rects in hs.items():
            if not key.isdigit() or not 0<=int(key)<s['pages'] or not isinstance(rects,list) or len(rects)>500: raise ValueError('Invalid highlight page')
            for r in rects:
                if not isinstance(r,list) or len(r)!=4 or not all(isinstance(v,(int,float)) and math.isfinite(v) for v in r) or not (0<=r[0]<r[2]<=1 and 0<=r[1]<r[3]<=1): raise ValueError('Invalid highlight rectangle')
        s['highlights']=hs
        s['highlight_mode']='manual'
        s.pop('auto_coverage',None)
    apply_ai_threshold(s)
    if not highlighting_enabled(s['result']):
        s['highlights']={}
        s.pop('auto_coverage',None)
    elif s.get('highlight_mode','manual')=='auto' and any(k in patch for k in ['kind','result','highlight_mode','placement']):
        s['highlights'],s['auto_coverage']=automatic_highlights(s)
    if s['kind']=='similarity' and s.get('source_mode','auto')=='auto':
        s['source_preview']=simulated_sources(s)
    elif not highlighting_enabled(s['result']): s['source_preview']=[]
    s.setdefault('source_pool',DEFAULT_SOURCE_POOL)
    s['overview_pages']=report_prefix(s)
    save(s);return jsonify(s)
@app.get('/api/projects/<pid>/page/<int:index>')
def preview(pid,index):
    d=compose(get_project(pid),index)
    mobile=request.args.get('quality')=='mobile'
    scale=.85 if mobile else 1.2
    pix=d[0].get_pixmap(matrix=fitz.Matrix(scale,scale),alpha=False)
    image=pix.tobytes('jpeg',jpg_quality=78) if mobile else pix.tobytes('png')
    d.close();return send_file(io.BytesIO(image),mimetype='image/jpeg' if mobile else 'image/png')
@app.get('/api/projects/<pid>/export')
def export(pid):
    s=get_project(pid);d=compose(s)
    data=d.tobytes(garbage=4,deflate=True)
    for cand in [Path('/storage/emulated/0/Download'), DATA/'exports']:
        try:
            cand.mkdir(parents=True, exist_ok=True)
            (cand / f"system-a-{s['kind']}-{s['id'][:8]}.pdf").write_bytes(data)
        except Exception:
            pass
    with db() as c: c.execute('INSERT INTO exports(project_id,created,pages) VALUES(?,?,?)',(pid,datetime.now(timezone.utc).isoformat(),len(d)))
    d.close()
    return send_file(io.BytesIO(data),mimetype='application/pdf',as_attachment=True,download_name='system-a-'+s['kind']+'-research.pdf')

if __name__=='__main__':
    app.run(host='127.0.0.1',port=8765,debug=False)

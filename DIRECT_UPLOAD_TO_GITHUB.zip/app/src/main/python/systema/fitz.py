import io
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import pypdf
from reportlab.pdfgen import canvas as rl_canvas
from reportlab.lib.utils import ImageReader

PAGE_W, PAGE_H, SCALE = 810.0, 1049.0399169921875, 2.0

class Point:
    def __init__(self, x, y=None):
        if isinstance(x, Point): self.x, self.y = x.x, x.y
        elif y is None: self.x, self.y = float(x[0]), float(x[1])
        else: self.x, self.y = float(x), float(y)

class Matrix:
    def __init__(self, sx=1.0, sy=1.0): self.sx, self.sy = float(sx), float(sy)

class Rect:
    def __init__(self, x0, y0=None, x1=None, y1=None):
        if isinstance(x0, Rect): self.x0, self.y0, self.x1, self.y1 = x0.x0, x0.y0, x0.x1, x0.y1
        elif y0 is None: self.x0, self.y0, self.x1, self.y1 = float(x0[0]), float(x0[1]), float(x0[2]), float(x0[3])
        else: self.x0, self.y0, self.x1, self.y1 = float(x0), float(y0), float(x1), float(y1)
    @property
    def width(self): return max(0.0, self.x1 - self.x0)
    @property
    def height(self): return max(0.0, self.y1 - self.y0)
    def intersects(self, o):
        o = Rect(o)
        return not (self.x1 <= o.x0 or self.x0 >= o.x1 or self.y1 <= o.y0 or self.y0 >= o.y1)
    def __ior__(self, o):
        o = Rect(o)
        self.x0, self.y0, self.x1, self.y1 = min(self.x0, o.x0), min(self.y0, o.y0), max(self.x1, o.x1), max(self.y1, o.y1)
        return self
    def __getitem__(self, i): return (self.x0, self.y0, self.x1, self.y1)[i]

class Font:
    def __init__(self, fontfile=None):
        self.fontfile = str(fontfile) if fontfile else None
        self.ascender, self.descender, self._cache = 0.82, -0.22, {}
    def text_length(self, text, fontsize=11):
        px = max(6, int(round(fontsize * 10)))
        if px not in self._cache:
            try: self._cache[px] = ImageFont.truetype(self.fontfile, px)
            except Exception: self._cache[px] = ImageFont.load_default()
        try: return self._cache[px].getlength(str(text)) / 10.0
        except Exception: return len(str(text)) * fontsize * 0.52

class Pixmap:
    def __init__(self, im): self.im = im
    def tobytes(self, fmt="png", jpg_quality=85):
        b = io.BytesIO()
        if fmt.lower() in ("jpg", "jpeg"): self.im.convert("RGB").save(b, format="JPEG", quality=jpg_quality)
        else: self.im.save(b, format="PNG")
        return b.getvalue()

class _EmptyTables: tables = []

class Page:
    def __init__(self, doc, index, width=PAGE_W, height=PAGE_H, bg_img=None, pypdf_page=None):
        self.doc, self.index, self.rect, self.pypdf_page = doc, index, Rect(0, 0, width, height), pypdf_page
        self._redactions, self._fonts = [], {}
        self.cw, self.ch = int(round(width * SCALE)), int(round(height * SCALE))
        if bg_img is not None:
            self.img = bg_img.convert("RGBA").resize((self.cw, self.ch), Image.Resampling.LANCZOS)
        else:
            self.img = Image.new("RGBA", (self.cw, self.ch), (255, 255, 255, 255))
            if pypdf_page is not None: self._render_pypdf_text()
    def _render_pypdf_text(self):
        txt = self.get_text()
        if not txt.strip(): return
        draw = ImageDraw.Draw(self.img)
        fp = self.doc._default_font_path()
        try: f = ImageFont.truetype(fp, int(10.5 * SCALE)) if fp else ImageFont.load_default()
        except Exception: f = ImageFont.load_default()
        y, max_w = int(50 * SCALE), int((self.rect.width - 100) * SCALE)
        for para in txt.splitlines():
            words = para.split()
            if not words: y += int(14 * SCALE); continue
            line = ""
            for w in words:
                test = (line + " " + w).strip()
                if f.getlength(test) > max_w and line:
                    draw.text((int(50 * SCALE), y), line, fill=(30, 30, 30, 255), font=f)
                    y += int(14 * SCALE); line = w
                else: line = test
            if line: draw.text((int(50 * SCALE), y), line, fill=(30, 30, 30, 255), font=f); y += int(15 * SCALE)
            if y > self.ch - int(50 * SCALE): break
    def find_tables(self, strategy="lines"): return _EmptyTables()
    def get_text(self, mode="text", sort=False):
        raw = (self.pypdf_page.extract_text() or "") if self.pypdf_page else ""
        if mode == "text": return raw
        if mode == "dict": return {"blocks": []}
        if mode == "words":
            out, y, max_w, bno = [], 50.0, self.rect.width - 100.0, 0
            for para in raw.splitlines():
                wlist = para.split()
                if not wlist: y += 14.0; continue
                x, lno = 50.0, 0
                for wi, w in enumerate(wlist):
                    ww = len(w) * 5.5
                    if x + ww > 50.0 + max_w and x > 50.0: y += 14.0; x = 50.0; lno += 1
                    out.append((x, y, x + ww, y + 11.0, w, bno, lno, wi))
                    x += ww + 4.5
                y += 15.0; bno += 1
                if y > self.rect.height - 50.0: break
            return out
        return raw
    def add_redact_annot(self, box, fill=False): self._redactions.append(Rect(box))
    def apply_redactions(self, images=0, graphics=0, text=0):
        draw = ImageDraw.Draw(self.img)
        for r in self._redactions:
            if r.x0 == 45 and r.y0 == 65 and r.x1 == 766 and r.y1 == 570:
                draw.rectangle([int(45*SCALE), int(65*SCALE), int(766*SCALE), int(465*SCALE)], fill=(255, 255, 255, 255))
            else:
                draw.rectangle([int(r.x0*SCALE), int(r.y0*SCALE), int(r.x1*SCALE), int(r.y1*SCALE)], fill=(255, 255, 255, 255))
        self._redactions.clear()
    def insert_font(self, fontname="SA_NotoR", fontfile=None):
        if fontfile: self._fonts[fontname] = str(fontfile)
    def _load_font(self, fn, fs):
        fp = self._fonts.get(fn) or self.doc._default_font_path()
        try: return ImageFont.truetype(fp, max(8, int(round(fs * SCALE)))) if fp else ImageFont.load_default()
        except Exception: return ImageFont.load_default()
    def _rgba(self, c, op=1.0):
        return None if c is None else (int(round(c[0]*255)), int(round(c[1]*255)), int(round(c[2]*255)), int(round(op*255)))
    def draw_rect(self, rect, color=None, fill=None, fill_opacity=1.0, overlay=True):
        r = Rect(rect)
        box = [int(round(r.x0*SCALE)), int(round(r.y0*SCALE)), int(round(r.x1*SCALE)), int(round(r.y1*SCALE))]
        if fill_opacity < 1.0 and fill is not None:
            layer = Image.new("RGBA", self.img.size, (0, 0, 0, 0))
            ImageDraw.Draw(layer).rectangle(box, fill=self._rgba(fill, fill_opacity), outline=self._rgba(color, 1.0))
            self.img = Image.alpha_composite(self.img, layer)
        else:
            ImageDraw.Draw(self.img).rectangle(box, fill=self._rgba(fill, 1.0), outline=self._rgba(color, 1.0))
    def draw_oval(self, rect, color=None, fill=None, overlay=True):
        r = Rect(rect)
        ImageDraw.Draw(self.img).ellipse([int(round(r.x0*SCALE)), int(round(r.y0*SCALE)), int(round(r.x1*SCALE)), int(round(r.y1*SCALE))], fill=self._rgba(fill, 1.0), outline=self._rgba(color, 1.0))
    def draw_circle(self, center, radius, color=None, fill=None, overlay=True):
        p, rad = Point(center), float(radius)
        self.draw_oval(Rect(p.x - rad, p.y - rad, p.x + rad, p.y + rad), color=color, fill=fill)
    def draw_line(self, p1, p2, color=(0, 0, 0), width=1.0):
        ImageDraw.Draw(self.img).line([int(round(p1[0]*SCALE)), int(round(p1[1]*SCALE)), int(round(p2[0]*SCALE)), int(round(p2[1]*SCALE))], fill=self._rgba(color, 1.0), width=max(1, int(round(width*SCALE))))
    def insert_text(self, point, text, fontsize=11, fontname="SA_NotoR", color=(0, 0, 0), overlay=True):
        ImageDraw.Draw(self.img).text((int(round(point[0]*SCALE)), int(round((point[1]-fontsize*0.82)*SCALE))), str(text), fill=self._rgba(color, 1.0), font=self._load_font(fontname, fontsize))
    def insert_textbox(self, rect, text, fontsize=11, fontname="SA_NotoR", color=(0, 0, 0), overlay=True):
        r, f = Rect(rect), self._load_font(fontname, fontsize)
        max_w, lines = r.width * SCALE, []
        for raw in str(text).split("\n"):
            cur = ""
            for w in raw.split(" "):
                test = (cur + " " + w).strip() if cur else w
                if f.getlength(test) > max_w and cur: lines.append(cur); cur = w
                else: cur = test
            lines.append(cur)
        lh = fontsize * 1.22
        if len(lines) * lh > r.height + 4: return -1.0
        draw, y = ImageDraw.Draw(self.img), r.y0
        for ln in lines: draw.text((int(round(r.x0*SCALE)), int(round(y*SCALE))), ln, fill=self._rgba(color, 1.0), font=f); y += lh
        return r.height - len(lines) * lh
    def insert_image(self, rect, filename=None, stream=None):
        r = Rect(rect)
        im = Image.open(filename).convert("RGBA") if filename else Image.open(io.BytesIO(stream)).convert("RGBA")
        im = im.resize((max(1, int(round(r.width*SCALE))), max(1, int(round(r.height*SCALE)))), Image.Resampling.LANCZOS)
        self.img.paste(im, (int(round(r.x0*SCALE)), int(round(r.y0*SCALE))), im)
    def show_pdf_page(self, rect, src_doc, page_no, clip=None, keep_proportion=True):
        r, sp = Rect(rect), src_doc[page_no]
        sub = sp.img.crop((int(round(clip.x0*SCALE)), int(round(clip.y0*SCALE)), int(round(clip.x1*SCALE)), int(round(clip.y1*SCALE)))) if clip else sp.img
        w, h = max(1, int(round(r.width*SCALE))), max(1, int(round(r.height*SCALE)))
        if keep_proportion and clip is None:
            sw, sh = sub.size
            ratio = min(w/sw, h/sh)
            nw, nh = max(1, int(round(sw*ratio))), max(1, int(round(sh*ratio)))
            res = sub.resize((nw, nh), Image.Resampling.LANCZOS)
            self.img.paste(res, (int(round(r.x0*SCALE))+(w-nw)//2, int(round(r.y0*SCALE))+(h-nh)//2), res)
        else:
            res = sub.resize((w, h), Image.Resampling.LANCZOS)
            self.img.paste(res, (int(round(r.x0*SCALE)), int(round(r.y0*SCALE))), res)
    def get_pixmap(self, matrix=None, clip=None, alpha=False):
        im = self.img
        if clip:
            c = Rect(clip)
            im = im.crop((int(round(c.x0*SCALE)), int(round(c.y0*SCALE)), int(round(c.x1*SCALE)), int(round(c.y1*SCALE))))
            bw, bh = c.width, c.height
        else: bw, bh = self.rect.width, self.rect.height
        sx, sy = (matrix.sx, matrix.sy) if matrix else (1.0, 1.0)
        out = im.resize((max(1, int(round(bw*sx))), max(1, int(round(bh*sy)))), Image.Resampling.LANCZOS)
        return Pixmap(out if alpha else out.convert("RGB"))

class Document:
    def __init__(self, path=None, stream=None, filetype=None):
        self.pages, self.is_encrypted, self._root = [], False, Path(__file__).resolve().parent
        if path is not None:
            p = Path(path)
            if p.name in ("ai_master.pdf", "similarity_master.pdf"): self._load_master(p.name)
            else: self._load_pdf_bytes(p.read_bytes())
        elif stream is not None: self._load_pdf_bytes(stream)
    def _default_font_path(self):
        c = self._root / "fonts" / "NotoR.ttf"
        return str(c) if c.exists() else None
    def _load_master(self, name):
        bg_dir = self._root / "templates" / "master_bg"
        prefix = "ai" if name == "ai_master.pdf" else "sim"
        for i in range(1, (3 if prefix == "ai" else 4) + 1):
            ip = bg_dir / f"{prefix}-0{i}.png"
            self.pages.append(Page(self, i-1, PAGE_W, PAGE_H, bg_img=Image.open(ip) if ip.exists() else None))
    def _load_pdf_bytes(self, data):
        reader = pypdf.PdfReader(io.BytesIO(data))
        self.is_encrypted = reader.is_encrypted
        for idx, p in enumerate(reader.pages):
            mb = p.mediabox
            self.pages.append(Page(self, idx, float(mb.width or PAGE_W), float(mb.height or PAGE_H), pypdf_page=p))
    def new_page(self, width=PAGE_W, height=PAGE_H):
        p = Page(self, len(self.pages), width, height)
        self.pages.append(p); return p
    def insert_pdf(self, other, from_page=0, to_page=0):
        for i in range(from_page, to_page+1):
            s = other[i]
            self.pages.append(Page(self, len(self.pages), s.rect.width, s.rect.height, bg_img=s.img.copy()))
    def tobytes(self, garbage=0, deflate=True):
        buf = io.BytesIO()
        c = rl_canvas.Canvas(buf, pagesize=(PAGE_W, PAGE_H))
        for p in self.pages:
            c.setPageSize((p.rect.width, p.rect.height))
            ib = io.BytesIO()
            p.img.convert("RGB").save(ib, format="JPEG", quality=92)
            ib.seek(0)
            c.drawImage(ImageReader(ib), 0, 0, width=p.rect.width, height=p.rect.height)
            c.showPage()
        c.save(); return buf.getvalue()
    def close(self): pass
    def __len__(self): return len(self.pages)
    def __getitem__(self, i): return self.pages[len(self.pages)+i if i<0 else i]
    def __iter__(self): return iter(self.pages)

def open(path=None, stream=None, filetype=None): return Document(path=path, stream=stream, filetype=filetype)

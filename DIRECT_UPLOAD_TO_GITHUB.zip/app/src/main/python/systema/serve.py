from app import app
from waitress import serve

if __name__ == "__main__":
    print("Open http://127.0.0.1:8766 in your browser.", flush=True)
    serve(app, host="127.0.0.1", port=8766, threads=4)

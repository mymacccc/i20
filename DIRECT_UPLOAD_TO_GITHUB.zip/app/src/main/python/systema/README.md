# System A browser app

Requires Python 3.10 or newer. Extract the ZIP and run these commands from the SystemA-Web folder:

    python -m venv .venv

Activate it (Windows: `.venv\Scripts\activate`; macOS/Linux: `source .venv/bin/activate`), then run:

    python -m pip install -r requirements.txt
    python serve.py

Open http://127.0.0.1:8766 in a browser. The app creates its local database and uploads folder automatically. To import Word documents directly, install LibreOffice locally or point SYSTEM_A_SOFFICE at its executable.

Includes PDF upload, AI and Similarity previews, editable report fields, saved projects, and PDF export. Preview percentages and sources are simulated. This source package does not include the former VPS sign-in, external source search, or experimental inference stack. The supplied launcher listens only on this computer; do not expose it publicly without authentication.
